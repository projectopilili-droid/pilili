import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { siteFromV0Chat, siteInstructions, V0_SITE_FAILED } from "./v0.ts";

describe("v0 site", () => {
  it("reads the preview link and the html", () => {
    const site = siteFromV0Chat({
      name: "Loja",
      latestVersion: {
        status: "completed",
        demoUrl: "https://demo.v0.dev/exemplo",
        files: [{ name: "index.html", content: "<html><body><h1>Loja</h1></body></html>" }],
      },
    });
    assert.equal(site?.preview, "https://demo.v0.dev/exemplo");
    assert.match(site?.html || "", /Loja/);
    const react = siteFromV0Chat({
      latestVersion: {
        status: "completed",
        demoUrl: "https://demo.v0.dev/loja",
        screenshotUrl: "https://exemplo.test/shot.jpg",
        files: [{ name: "app/page.tsx", content: "export default function Page(){ return <html><body>Camisa</body></html> }" }],
      },
    });
    assert.equal(react?.html, "");
    assert.equal(react?.shot, "https://exemplo.test/shot.jpg");
    assert.equal(react?.preview, "https://demo.v0.dev/loja");
    assert.equal(react?.code.includes("page.tsx"), true);
    assert.equal(V0_SITE_FAILED, "Não foi possível gerar o site agora");
    const rules = siteInstructions(true);
    assert.match(rules, /Não cries um site novo/);
    assert.match(rules, /três riscos/);
    assert.match(rules, /pessoas são negras/);
    assert.equal(rules.includes("\u2014"), false);
  });

  it("fails closed when v0 returns nothing usable", () => {
    assert.equal(siteFromV0Chat({ latestVersion: { status: "failed", files: [] } }), null);
    assert.equal(siteFromV0Chat(null), null);
  });
});
