import type { Json } from "@/lib/pilili/types";
import { shapeLibraryRecord } from "@/lib/pilili/library-image";
import { addLibraryItem } from "./db-helpers";

export {
  LIBRARY_MISS,
  keepVideoFile,
  mediaFromStored,
  slimArtifact,
  visibleImageUrl,
} from "@/lib/pilili/library-media";

export async function persistLibraryItem(opts: {
  id: string;
  userId: string;
  projectId?: string | null;
  conversationId?: string | null;
  kind: string;
  title: string;
  power?: string | null;
  payload: { [key: string]: Json };
}): Promise<{ [key: string]: Json }> {
  const shaped = await shapeLibraryRecord(opts.kind, opts.payload);
  await addLibraryItem({
    id: opts.id,
    userId: opts.userId,
    projectId: opts.projectId ?? null,
    conversationId: opts.conversationId ?? null,
    kind: opts.kind,
    title: opts.title,
    body: shaped.body,
    imageUrl: shaped.imageUrl,
    mime: shaped.mime,
    power: opts.power ?? null,
  });
  return shaped.live;
}
