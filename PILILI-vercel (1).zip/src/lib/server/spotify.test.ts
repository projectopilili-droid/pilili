import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { isDjSession, parseDjArc, spotifyAuthorizeUrl, spotifyReady, spotifyRedirect, stylesFromMessage } from "../pilili/dj-session.ts";
import { musicAudioUrl } from "./integrations.ts";

describe("spotify session", () => {
  it("recognises a session and keeps the playlist private in the auth link", () => {
    assert.equal(isDjSession("Quero uma sessão DJ PILILÍ. Ocasião: Festa."), true);
    assert.equal(isDjSession("Cria uma música original"), false);
    assert.equal(spotifyReady("id", "secret"), true);
    assert.equal(spotifyReady("", "secret"), false);
    const url = spotifyAuthorizeUrl({ clientId: "abc", redirect: spotifyRedirect("https://pilili.test"), state: "s1" });
    assert.match(url, /playlist-modify-private/);
    assert.match(url, /redirect_uri=https%3A%2F%2Fpilili\.test%2Fapi%2Fspotify%2Fcallback/);
    assert.deepEqual(stylesFromMessage("Estilos: Kizomba, Semba. Vibe: Festiva."), ["Kizomba", "Semba"]);
  });

  it("reads the arc without invented track names", () => {
    const arc = parseDjArc(
      '{"title":"Noite","arc":[{"phase":"início","minutes":20,"energy":3,"style":"Kizomba","notes":"Abre leve.","queries":["kizomba"]}]}',
    );
    assert.equal(arc?.title, "Noite");
    assert.equal(arc?.arc[0]?.phase, "início");
    assert.equal(arc?.arc[0]?.queries[0], "kizomba");
    assert.equal(parseDjArc("sem json"), null);
    assert.equal(musicAudioUrl({ audio_url: "https://audio.test/a.mp3" }), "https://audio.test/a.mp3");
    assert.equal(musicAudioUrl({}), "");
  });
});
