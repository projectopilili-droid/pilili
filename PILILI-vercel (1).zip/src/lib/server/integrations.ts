import { readFileSync } from "node:fs";
import { join } from "node:path";

export const INTEGRATION_PENDING = "A integração está a ser activada.";

let fileEnv: { [key: string]: string } | null = null;

function readFileEnv(): { [key: string]: string } {
  if (fileEnv) return fileEnv;
  fileEnv = {};
  try {
    const text = readFileSync(join(process.cwd(), ".env"), "utf8");
    for (const line of text.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eq = trimmed.indexOf("=");
      if (eq < 1) continue;
      const key = trimmed.slice(0, eq).trim();
      let value = trimmed.slice(eq + 1).trim();
      if (
        (value.startsWith("\"") && value.endsWith("\"")) ||
        (value.startsWith("'") && value.endsWith("'"))
      ) {
        value = value.slice(1, -1);
      }
      fileEnv[key] = value;
    }
  } catch {
    /* no local env file */
  }
  return fileEnv;
}

export function envValue(name: string): string {
  return process.env[name]?.trim() || readFileEnv()[name]?.trim() || "";
}

export function musicEndpoint(): { url: string; key: string } | null {
  const key = envValue("MUSIC_API_KEY") || envValue("SUNO_API_KEY");
  const url = envValue("MUSIC_API_URL");
  if (!key || !url) return null;
  return { key, url };
}

export function documentEndpoint(): { url: string; key: string } | null {
  const key = envValue("DOCUMENT_API_KEY");
  const url = envValue("DOCUMENT_API_URL");
  if (!key || !url) return null;
  return { key, url };
}

export function netlifyConfig(): { key: string; siteId: string } | null {
  const key = envValue("NETLIFY_API_KEY");
  const siteId = envValue("NETLIFY_SITE_ID");
  if (!key || !siteId) return null;
  return { key, siteId };
}

export const NETLIFY_NOT_CONFIGURED = "A publicação no Netlify ainda não está configurada.";

export async function publishNetlifySite(input: {
  html: string;
  name: string;
}): Promise<{ ok: true; url: string } | { ok: false; message: string }> {
  const config = netlifyConfig();
  if (!config) return { ok: false, message: NETLIFY_NOT_CONFIGURED };
  const html = input.html.trim();
  if (!/<html[\s>]/i.test(html) || html.length > 500_000) {
    return { ok: false, message: "O site ainda não está pronto para publicar." };
  }
  const { createHash } = await import("node:crypto");
  const sha = createHash("sha1").update(html).digest("hex");
  const auth = { Authorization: `Bearer ${config.key}` };
  let create: Response;
  try {
    create = await fetch(`https://api.netlify.com/api/v1/sites/${encodeURIComponent(config.siteId)}/deploys`, {
      method: "POST",
      headers: { ...auth, "Content-Type": "application/json" },
      body: JSON.stringify({
        files: { "/index.html": sha },
        title: input.name.slice(0, 80) || "PILILI",
      }),
    });
  } catch {
    return { ok: false, message: "Não consegui publicar agora. Tenta outra vez." };
  }
  if (!create.ok) return { ok: false, message: "Não consegui publicar agora. Tenta outra vez." };
  const deploy = (await create.json()) as {
    id?: string;
    required?: string[];
    ssl_url?: string;
    deploy_ssl_url?: string;
    url?: string;
  };
  if (!deploy.id) return { ok: false, message: "Não consegui publicar agora. Tenta outra vez." };
  if (deploy.required?.includes(sha)) {
    const upload = await fetch(`https://api.netlify.com/api/v1/deploys/${deploy.id}/files/index.html`, {
      method: "PUT",
      headers: { ...auth, "Content-Type": "application/octet-stream" },
      body: html,
    });
    if (!upload.ok) return { ok: false, message: "Não consegui publicar agora. Tenta outra vez." };
  }
  const url = (await netlifySiteUrl(config)) || deploy.ssl_url || deploy.deploy_ssl_url || deploy.url || "";
  return { ok: true, url };
}

async function netlifySiteUrl(config: { key: string; siteId: string }): Promise<string> {
  try {
    const res = await fetch(`https://api.netlify.com/api/v1/sites/${encodeURIComponent(config.siteId)}`, {
      headers: { Authorization: `Bearer ${config.key}` },
    });
    if (!res.ok) return "";
    const site = (await res.json()) as { ssl_url?: string; url?: string };
    return site.ssl_url || site.url || "";
  } catch {
    return "";
  }
}

export function paymentEndpoint(): { url: string; key: string } | null {
  const key = envValue("PAYMENT_API_KEY") || envValue("MULTICAIXA_API_KEY");
  const url = envValue("PAYMENT_API_URL");
  if (!key || !url) return null;
  return { key, url };
}

export function musicAudioUrl(json: { audioUrl?: string; audio_url?: string; url?: string }): string {
  return json.audioUrl || json.audio_url || json.url || "";
}

export async function requestMusic(input: {
  description: string;
  style: string;
  language: string;
}): Promise<{ ok: true; audioUrl: string } | { ok: false; message: string }> {
  const config = musicEndpoint();
  if (!config) return { ok: false, message: INTEGRATION_PENDING };
  const res = await fetch(config.url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      prompt: input.description,
      style: input.style,
      language: input.language,
    }),
  });
  if (!res.ok) return { ok: false, message: INTEGRATION_PENDING };
  const json = (await res.json()) as { audioUrl?: string; audio_url?: string; url?: string };
  const audioUrl = musicAudioUrl(json);
  if (!audioUrl) return { ok: false, message: INTEGRATION_PENDING };
  return { ok: true, audioUrl };
}

export type PaymentConfirmation = {
  reference: string;
  amountKz: number;
  planId: string;
  method: string;
};

/**
 * Structure for a later payment confirmation.
 * Does not call a gateway and does not change the plan or the credits.
 */
export function reviewPaymentConfirmation(input: PaymentConfirmation): {
  ok: false;
  applied: false;
  message: string;
} {
  const reference = input.reference.trim();
  const planId = input.planId.trim();
  if (reference.length < 3 || planId.length < 2 || !Number.isFinite(input.amountKz) || input.amountKz <= 0) {
    return { ok: false, applied: false, message: "Falta a referência do pagamento." };
  }
  paymentEndpoint();
  return { ok: false, applied: false, message: INTEGRATION_PENDING };
}
