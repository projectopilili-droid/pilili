function safeDetail(body: string): string {
  return body
    .replace(/Bearer\s+\S+/gi, "")
    .replace(/sk-[A-Za-z0-9_-]+/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 180);
}

export function providerFailureMessage(status: number, body: string): string {
  if (/spending-limit|personal-team-blocked|out of credits|quota/i.test(body)) {
    return "A cota de inteligência deste PILILÍ esgotou-se temporariamente. O motor está ligado. Falta recarregar a cota. Tenta mais tarde.";
  }
  if (status === 401 || status === 403) {
    return "A inteligência do PILILÍ não está autenticada neste ambiente.";
  }
  if (status === 429) return "Há muita gente a usar agora. Tenta daqui a pouco.";
  if (status >= 500) return "O motor falhou do lado do serviço. Tenta outra vez.";
  if (status === 422 || status === 410) {
    const detail = safeDetail(body);
    return detail
      ? `O pedido foi recusado pelo motor (${status}). ${detail}`
      : `O pedido foi recusado pelo motor (${status}).`;
  }
  return `O motor devolveu um erro (${status}).`;
}
