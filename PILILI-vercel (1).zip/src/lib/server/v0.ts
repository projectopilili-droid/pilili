import { envValue } from "./integrations.ts";

export const V0_SITE_FAILED = "Não foi possível gerar o site agora";

type V0File = { name?: string; content?: string };

type V0Chat = {
  id?: string;
  name?: string;
  webUrl?: string;
  latestVersion?: {
    status?: string;
    demoUrl?: string;
    screenshotUrl?: string;
    files?: V0File[];
  };
};

export type V0Site = {
  html: string;
  preview: string;
  shot: string;
  name: string;
  code: string;
  chatId: string;
};

function filesOf(chat: V0Chat): V0File[] {
  return Array.isArray(chat.latestVersion?.files) ? chat.latestVersion.files : [];
}

export function siteFromV0Chat(chat: V0Chat | null | undefined): V0Site | null {
  if (!chat) return null;
  const files = filesOf(chat);
  const htmlFile = files.find((file) => /^\s*(<!doctype html|<html[\s>])/i.test(file.content || ""));
  const html = (htmlFile?.content || "").slice(0, 350_000);
  const preview = (chat.latestVersion?.demoUrl || "").trim();
  const shot = (chat.latestVersion?.screenshotUrl || "").trim();
  const code = files
    .filter((file) => file.name && file.content)
    .slice(0, 6)
    .map((file) => `${file.name}\n${file.content}`)
    .join("\n\n")
    .slice(0, 80_000);
  if (!html && !preview && !shot && code.length < 40) return null;
  if (chat.latestVersion?.status === "failed" && !html && !preview && !shot) return null;
  return {
    html,
    preview,
    shot,
    name: (chat.name || "Site profissional").slice(0, 80),
    code,
    chatId: (chat.id || "").trim(),
  };
}

export function siteInstructions(editing: boolean): string {
  const edit = editing
    ? " Já existe um site nesta conversa. Altera esse site. Não cries um site novo do zero."
    : "";
  return (
    "Cria ou actualiza um site profissional completo, de uma só página, para o pedido." +
    edit +
    " Todos os textos visíveis ficam em português de Angola, profissional, curto e natural. Não uses português do Brasil. Não uses travessão longo. Não faças perguntas. Não inventes nomes de produtos ou serviços que o pedido não disse. Se não houver nomes, usa rótulos simples como Artigo ou Serviço, ou deixa em branco. Sem frases forçadas. Inclui animações suaves: fade ao entrar, movimento ligeiro no scroll e hover nos botões e nos cartões." +
    " O menu de três riscos tem de funcionar. Ao tocar, abre um painel com as secções principais, como Colecção e Contactos. Fecha ao tocar fora do painel ou num item. O botão tem acção real, não é só desenho." +
    " Se a pessoa enviar imagens, usa essas imagens directamente no hero, nos produtos ou na secção indicada. Não as troques por outras." +
    " Quando uma imagem mostrar pessoas, as pessoas são negras, com presença, bem vestidas, estilo moderno e confiante, luz natural e fotografia profissional. O contexto é Luanda e Angola de hoje. Sem cenário de miséria."
  );
}

function systemFor(context?: string | null, editing?: boolean): string {
  const model = context?.match(/modelo do site:\s*([a-z]+)/i)?.[1];
  const look = model ? ` O modelo visual pedido é ${model}.` : "";
  return siteInstructions(Boolean(editing)) + look;
}

async function readChat(id: string, key: string, signal: AbortSignal): Promise<V0Chat | null> {
  const res = await fetch(`https://api.v0.dev/v1/chats/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${key}` },
    signal,
  });
  if (!res.ok) return null;
  return (await res.json()) as V0Chat;
}

export async function createV0Site(
  message: string,
  context?: string | null,
  onTick?: () => void,
  extra?: { chatId?: string | null; images?: string[]; quick?: boolean },
): Promise<{ ok: true; site: V0Site } | { ok: false }> {
  try {
    return await createV0SiteOnce(message, context, onTick, extra);
  } catch {
    return { ok: false };
  }
}

async function createV0SiteOnce(
  message: string,
  context?: string | null,
  onTick?: () => void,
  extra?: { chatId?: string | null; images?: string[]; quick?: boolean },
): Promise<{ ok: true; site: V0Site } | { ok: false }> {
  const key = envValue("V0_API_KEY");
  const text = message.replace(/\s+/g, " ").trim();
  if (!key || !text) return { ok: false };
  const prior = extra?.chatId?.trim() || "";
  const signal = AbortSignal.timeout(180_000);
  const images = (extra?.images ?? [])
    .filter((url) => url.startsWith("data:image/") || url.startsWith("http"))
    .filter((url) => url.length <= 1_400_000)
    .slice(0, 3)
    .map((url) => ({ url }));
  const prompt = prior ? `Altera o site que já existe. Não cries outro. ${text}` : text;
  let created: Response;
  try {
    created = await fetch(prior ? `https://api.v0.dev/v1/chats/${encodeURIComponent(prior)}/messages` : "https://api.v0.dev/v1/chats", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: prompt.slice(0, 4000),
        system: systemFor(context, Boolean(prior)),
        ...(prior ? {} : { chatPrivacy: "unlisted" }),
        ...(images.length ? { attachments: images } : {}),
        modelConfiguration: { modelId: "v0-auto", responseMode: "sync" },
      }),
      signal,
    });
  } catch {
    return { ok: false };
  }
  if (!created.ok) return { ok: false };
  let chat = (await created.json()) as V0Chat;
  if (!chat.id && prior) chat.id = prior;
  const id = chat.id || "";
  let waits = 0;
  let shot = "";
  const limit = extra?.quick ? 4 : 16;
  while (id && waits < limit && chat.latestVersion?.status !== "failed" && !shot) {
    const version = chat.latestVersion;
    if (version?.screenshotUrl) shot = await displayableShot(version.screenshotUrl, key, signal);
    if (shot) break;
    onTick?.();
    if (version?.status === "failed") break;
    await new Promise((resolve) => setTimeout(resolve, 3000));
    const next = await readChat(id, key, signal).catch(() => null);
    if (!next) break;
    chat = next;
    waits += 1;
  }
  if (!shot && chat.latestVersion?.demoUrl) {
    const found = await openGraphImage(chat.latestVersion.demoUrl, signal);
    if (found) shot = await displayableShot(found, key, signal);
  }
  const site = siteFromV0Chat(chat);
  if (!site) return { ok: false };
  return { ok: true, site: { ...site, shot, chatId: site.chatId || prior } };
}

export async function readDemoHtml(pageUrl: string): Promise<string> {
  try {
    const res = await fetch(pageUrl, { signal: AbortSignal.timeout(8000), headers: { Accept: "text/html" } });
    if (!res.ok) return "";
    const html = (await res.text()).slice(0, 350_000);
    return /<!doctype html|<html[\s>]/i.test(html) ? html : "";
  } catch {
    return "";
  }
}

async function openGraphImage(pageUrl: string, signal: AbortSignal): Promise<string> {
  try {
    const res = await fetch(pageUrl, { signal, headers: { Accept: "text/html" } });
    if (!res.ok) return "";
    const html = (await res.text()).slice(0, 80_000);
    const found =
      html.match(/property=["']og:image["'][^>]*content=["']([^"']+)["']/i) ||
      html.match(/content=["']([^"']+)["'][^>]*property=["']og:image["']/i);
    return found?.[1]?.trim() || "";
  } catch {
    return "";
  }
}

async function displayableShot(url: string, key: string, signal: AbortSignal): Promise<string> {
  const shotUrl = url.includes("ignoreCache=") ? url : `${url}${url.includes("?") ? "&" : "?"}ignoreCache=1`;
  try {
    const bytes = await readShot(shotUrl, url, key, signal);
    if (!bytes || bytes.length < 2000) return "";
    if (!imageMime(bytes, "")) return "";
    const fitted = await fitShot(bytes);
    if (!fitted || fitted.length < 2000 || fitted.length > 420_000) return "";
    return `data:image/jpeg;base64,${fitted.toString("base64")}`;
  } catch {
    return "";
  }
}

async function readShot(shotUrl: string, url: string, key: string, signal: AbortSignal): Promise<Buffer | null> {
  const auth = { Authorization: `Bearer ${key}` };
  let res = await fetch(shotUrl, { signal, headers: auth, redirect: "manual" });
  if (res.status >= 300 && res.status < 400) {
    const loc = res.headers.get("location");
    if (!loc) return null;
    res = await fetch(loc, { signal });
  } else if (!res.ok) {
    res = await fetch(url, { signal, headers: auth, redirect: "manual" });
    if (res.status >= 300 && res.status < 400) {
      const loc = res.headers.get("location");
      if (!loc) return null;
      res = await fetch(loc, { signal });
    }
  }
  if (!res.ok) return null;
  return Buffer.from(await res.arrayBuffer());
}

function imageMime(bytes: Buffer, header: string): string {
  if (bytes[0] === 0xff && bytes[1] === 0xd8) return "image/jpeg";
  if (bytes[0] === 0x89 && bytes[1] === 0x50) return "image/png";
  if (bytes.length > 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "image/webp";
  return header.startsWith("image/") ? header : "";
}

async function fitShot(bytes: Buffer): Promise<Buffer | null> {
  try {
    const canvas = await import("@napi-rs/canvas");
    const image = await canvas.loadImage(bytes);
    const sample = canvas.createCanvas(32, 32);
    const probe = sample.getContext("2d");
    probe.drawImage(image, 0, 0, 32, 32);
    const pixels = probe.getImageData(0, 0, 32, 32).data;
    let min = 255;
    let max = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      const lum = pixels[i] * 0.3 + pixels[i + 1] * 0.59 + pixels[i + 2] * 0.11;
      if (lum < min) min = lum;
      if (lum > max) max = lum;
    }
    if (max - min < 18) return null;
    const width = Math.min(720, image.width || 720);
    const height = Math.max(1, Math.round(((image.height || 1) * width) / (image.width || width)));
    const frame = canvas.createCanvas(width, height);
    frame.getContext("2d").drawImage(image, 0, 0, width, height);
    const jpeg = frame.toBuffer("image/jpeg", 72);
    return jpeg.length > 420_000 ? null : jpeg;
  } catch {
    return null;
  }
}
