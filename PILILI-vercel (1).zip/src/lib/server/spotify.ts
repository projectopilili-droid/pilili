import { getSql } from "@/lib/db";
import { isDjSession, parseDjArc, spotifyAuthorizeUrl, spotifyReady, spotifyRedirect, stylesFromMessage } from "@/lib/pilili/dj-session";
import type { Json } from "@/lib/pilili/types";
import { uid } from "@/lib/utils";
import { envValue, INTEGRATION_PENDING } from "./integrations";
import { chatCompletion } from "./grok";

export { isDjSession };

function spotifyApp(): { id: string; secret: string } | null {
  const id = envValue("SPOTIFY_CLIENT_ID");
  const secret = envValue("SPOTIFY_CLIENT_SECRET");
  if (!spotifyReady(id, secret)) return null;
  return { id, secret };
}

type Track = { id: string; name: string; artists: string; url: string };

export async function createDjSession(opts: {
  userId: string;
  message: string;
  origin: string;
}): Promise<
  | { ok: true; title: string; reply: string; payload: { [key: string]: Json } }
  | { ok: false; message: string; connectUrl?: string }
> {
  const app = spotifyApp();
  if (!app) return { ok: false, message: INTEGRATION_PENDING };
  const linked = await readRefresh(opts.userId);
  if (!linked) {
    const connectUrl = await connectLink(opts.userId, opts.origin, app.id);
    return {
      ok: false,
      message: "Para criar a playlist, liga a tua conta Spotify. A música toca no Spotify, não aqui.",
      connectUrl,
    };
  }
  const access = await accessToken(app, linked);
  if (!access) {
    const connectUrl = await connectLink(opts.userId, opts.origin, app.id);
    return {
      ok: false,
      message: "A ligação ao Spotify expirou. Liga outra vez para criar a playlist.",
      connectUrl,
    };
  }
  let arcText = "";
  try {
    const result = await chatCompletion({
      role: "fast",
      maxTokens: 900,
      temperature: 0.4,
      messages: [
        {
          role: "system",
          content:
            "Responde só com JSON. Português de Angola, com tu e teu. Sem português do Brasil. Sem travessão longo. Sem expressões inventadas. Não inventes nomes de músicas.",
        },
        {
          role: "user",
          content: `Monta o arco da sessão. title é curto. arc tem início, meio, transição e final. Cada parte tem phase, minutes, energy de 1 a 10, style, notes numa frase, e queries com 2 pesquisas curtas de estilo para o Spotify.\n${opts.message}`,
        },
      ],
    });
    arcText = result.text;
  } catch {
    return { ok: false, message: "Não foi possível montar a sessão agora." };
  }
  const parsed = parseDjArc(arcText);
  if (!parsed) return { ok: false, message: "Não foi possível montar a sessão agora." };
  const styles = stylesFromMessage(opts.message);
  const queries = parsed.arc.flatMap((phase) => (phase.queries.length ? phase.queries : phase.style ? [phase.style] : styles)).slice(0, 8);
  const tracks = await searchTracks(access, queries.length ? queries : styles);
  if (!tracks.length) return { ok: false, message: "Não encontrei músicas no Spotify para esta sessão." };
  const playlist = await createPlaylist(access, parsed.title, tracks.map((track) => `spotify:track:${track.id}`));
  if (!playlist) return { ok: false, message: "Não foi possível criar a playlist no Spotify." };
  return {
    ok: true,
    title: parsed.title,
    reply: "A sessão ficou pronta. Abre a playlist no Spotify para ouvir.",
    payload: {
      occasion: occasionOf(opts.message),
      genres: styles,
      arc: parsed.arc.map((phase) => ({
        phase: phase.phase,
        minutes: phase.minutes,
        energy: phase.energy,
        style: phase.style,
        notes: phase.notes,
        references: [],
      })),
      tracks: tracks.map((track) => ({ name: track.name, artists: track.artists, url: track.url })),
      spotifyUrl: playlist,
    },
  };
}

function occasionOf(message: string): string {
  return message.match(/Ocasi[aã]o:\s*([^.]+)/i)?.[1]?.trim() || "";
}

async function connectLink(userId: string, origin: string, clientId: string): Promise<string> {
  const state = uid();
  const sql = await getSql();
  await sql`insert into spotify_states (state, user_id) values (${state}, ${userId})`;
  return spotifyAuthorizeUrl({ clientId, redirect: spotifyRedirect(origin), state });
}

async function readRefresh(userId: string): Promise<string> {
  const sql = await getSql();
  const rows = await sql<{ refresh_token: string }>`select refresh_token from spotify_accounts where user_id = ${userId} limit 1`;
  return rows[0]?.refresh_token || "";
}

async function accessToken(app: { id: string; secret: string }, refresh: string): Promise<string> {
  const body = new URLSearchParams({ grant_type: "refresh_token", refresh_token: refresh });
  const res = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${app.id}:${app.secret}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
  });
  if (!res.ok) return "";
  const json = (await res.json()) as { access_token?: string };
  return json.access_token || "";
}

async function searchTracks(token: string, queries: string[]): Promise<Track[]> {
  const seen = new Set<string>();
  const tracks: Track[] = [];
  for (const query of queries) {
    if (tracks.length >= 24) break;
    const url = `https://api.spotify.com/v1/search?type=track&limit=4&q=${encodeURIComponent(query)}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) continue;
    const json = (await res.json()) as {
      tracks?: { items?: { id?: string; name?: string; external_urls?: { spotify?: string }; artists?: { name?: string }[] }[] };
    };
    for (const item of json.tracks?.items ?? []) {
      if (!item.id || seen.has(item.id)) continue;
      seen.add(item.id);
      tracks.push({
        id: item.id,
        name: item.name || "Faixa",
        artists: (item.artists ?? []).map((artist) => artist.name).filter(Boolean).join(", "),
        url: item.external_urls?.spotify || "",
      });
    }
  }
  return tracks;
}

async function createPlaylist(token: string, title: string, uris: string[]): Promise<string> {
  const me = await fetch("https://api.spotify.com/v1/me", { headers: { Authorization: `Bearer ${token}` } });
  if (!me.ok) return "";
  const user = (await me.json()) as { id?: string };
  if (!user.id) return "";
  const created = await fetch(`https://api.spotify.com/v1/users/${encodeURIComponent(user.id)}/playlists`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      name: `PILILI - ${title}`.slice(0, 80),
      description: "Sessão privada criada pelo PILILÍ.",
      public: false,
    }),
  });
  if (!created.ok) return "";
  const playlist = (await created.json()) as { id?: string; external_urls?: { spotify?: string } };
  if (!playlist.id) return "";
  const added = await fetch(`https://api.spotify.com/v1/playlists/${playlist.id}/tracks`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ uris: uris.slice(0, 50) }),
  });
  if (!added.ok) return "";
  return playlist.external_urls?.spotify || `https://open.spotify.com/playlist/${playlist.id}`;
}

export async function finishSpotifyLink(opts: {
  code: string;
  state: string;
  origin: string;
}): Promise<boolean> {
  const app = spotifyApp();
  if (!app || !opts.code || !opts.state) return false;
  const sql = await getSql();
  const rows = await sql<{ user_id: string }>`select user_id from spotify_states where state = ${opts.state} limit 1`;
  const userId = rows[0]?.user_id;
  if (!userId) return false;
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code: opts.code,
    redirect_uri: spotifyRedirect(opts.origin),
  });
  const res = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${app.id}:${app.secret}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
  });
  if (!res.ok) return false;
  const json = (await res.json()) as { refresh_token?: string };
  if (!json.refresh_token) return false;
  await sql`
    insert into spotify_accounts (user_id, refresh_token)
    values (${userId}, ${json.refresh_token})
    on conflict (user_id) do update set refresh_token = excluded.refresh_token, updated_at = now()
  `;
  await sql`delete from spotify_states where state = ${opts.state}`;
  return true;
}
