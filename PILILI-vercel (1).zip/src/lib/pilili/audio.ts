export type AudioJob = "transcribe" | "merge" | "summary" | "points" | "document" | "video";

export type AudioSection = { heading: string; body: string };

const AUDIO_EXT = /\.(m4a|mp3|wav|ogg)$/i;

export function isAudioFile(name: string, mime: string): boolean {
  const type = mime.toLowerCase();
  return type.startsWith("audio/") || AUDIO_EXT.test(name);
}

export function audioJob(message: string, count: number): AudioJob {
  const text = message.toLowerCase();
  const bare = /analisa o que enviei/.test(text);
  if (/v[ií]deo|reels|tiktok/.test(text)) return "video";
  if (/compil|junt|\bmp3\b|\bm4a\b|ficheiro de [aá]udio|um s[oó] [aá]udio/.test(text)) return "merge";
  if (/organiz/.test(text) || (!bare && /resum|analisa|an[aá]lise/.test(text))) return "summary";
  if (/pontos/.test(text)) return "points";
  if (/proposta|documento|\bplano\b|\blista\b/.test(text)) return "document";
  if (/transcrev|transcri|passa a escrito|o que foi dito/.test(text)) return "transcribe";
  return count > 1 ? "summary" : "transcribe";
}

export function transcriptSections(files: { name: string; text: string }[]): AudioSection[] {
  return files
    .map((file) => ({ heading: file.name.trim() || "Áudio", body: clean(file.text) }))
    .filter((section) => section.body.length > 0);
}

export function isTranscriptDump(sections: AudioSection[], sources: AudioSection[]): boolean {
  if (sections.length < 2 || sources.length < 2) return false;
  const names = new Set(sources.map((source) => norm(source.heading)));
  const fileHeadings = sections.filter((section) => names.has(norm(section.heading)) || /\.(m4a|mp3|wav|ogg)$/i.test(section.heading)).length;
  if (fileHeadings >= 2) return true;
  const bodies = sources.map((source) => norm(source.body)).filter((body) => body.length > 24);
  const copied = sections.filter((section) => bodies.includes(norm(section.body))).length;
  return copied >= 2;
}

export function parseAudioSections(raw: string): { title: string; sections: AudioSection[] } | null {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const json = JSON.parse(raw.slice(start, end + 1)) as { title?: unknown; sections?: unknown };
    if (!Array.isArray(json.sections)) return null;
    const sections = json.sections
      .slice(0, 8)
      .map((item) => {
        const row = item && typeof item === "object" ? (item as Record<string, unknown>) : {};
        return { heading: clean(String(row.heading || "")).slice(0, 80), body: clean(String(row.body || "")) };
      })
      .filter((section) => section.body);
    if (!sections.length) return null;
    return { title: clean(String(json.title || "Áudio")).slice(0, 80), sections };
  } catch {
    return null;
  }
}

export function audioPlain(title: string, sections: AudioSection[]): string {
  return [title, ...sections.map((section) => `${section.heading}\n${section.body}`)].filter(Boolean).join("\n\n");
}

export function audioHtml(title: string, sections: AudioSection[]): string {
  const blocks = sections
    .map((section) => `<h2>${escapeHtml(section.heading)}</h2><p>${escapeHtml(section.body).replace(/\n/g, "<br/>")}</p>`)
    .join("");
  return `<h1>${escapeHtml(title)}</h1>${blocks}`;
}

function clean(value: string): string {
  return value.replace(/\u2014/g, "-").replace(/[ \t]+\n/g, "\n").trim();
}

function norm(value: string): string {
  return clean(value).toLowerCase().replace(/\s+/g, " ");
}

function escapeHtml(value: string): string {
  const amp = "&" + "amp;";
  const lt = "&" + "lt;";
  const gt = "&" + "gt;";
  const quot = "&" + "quot;";
  return value.replace(/&/g, amp).replace(/</g, lt).replace(/>/g, gt).replace(/"/g, quot);
}
