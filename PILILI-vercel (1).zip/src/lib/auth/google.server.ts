/** Server-only Google OAuth. Env wins when Vercel defines it. */
const FALLBACK_CLIENT_ID =
  "481496710990-jdffmgckm2jb1a909krtibtvfiv70lbm.apps.googleusercontent.com";
const FALLBACK_CLIENT_SECRET = "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";

export const GOOGLE_REDIRECT_URI = "https://pilili.app/api/auth/callback/google";

export function googleOAuthCredentials(): { clientId: string; clientSecret: string } {
  const clientId = process.env.GOOGLE_CLIENT_ID?.trim() || FALLBACK_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET?.trim() || FALLBACK_CLIENT_SECRET;
  return { clientId, clientSecret };
}
