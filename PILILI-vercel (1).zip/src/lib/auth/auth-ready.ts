import { createServerFn } from "@tanstack/react-start";

function filled(name: string): boolean {
  return Boolean(process.env[name]?.trim());
}

/** What this deployment can actually sign in with. Preview keeps the broker. */
export const authReady = createServerFn({ method: "GET" }).handler(async () => {
  return {
    database: filled("DATABASE_URL") || filled("POSTGRES_URL"),
    googleDirect: true,
    broker:
      (filled("GROK_AUTH_CLIENT_ID") && filled("GROK_AUTH_CLIENT_SECRET")) || !process.env.VERCEL,
  };
});
